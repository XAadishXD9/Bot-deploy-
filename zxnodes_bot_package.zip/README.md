# ZXNODES Discord LXC Manager Bot

This package contains an updated ZXNODES-branded Discord bot based on your uploaded file.

## Files
- `zxnodes_bot.py` - Updated bot file with full ZXNODES branding (replaced UNIXNODE → ZXNODES and updated logo).
- `requirements.txt` - Python dependencies.
- `README.md` - This file.

## Setup
1. Install dependencies:
```bash
pip install -r requirements.txt
```

2. Set environment variables:
- `DISCORD_TOKEN` - Your bot token
- `MAIN_ADMIN_ID` - Main admin Discord ID (optional)
- `VPS_USER_ROLE_ID` - Optional role ID
- `DEFAULT_STORAGE_POOL` - LXC storage pool name (default: default)
- `CPU_THRESHOLD`, `RAM_THRESHOLD`, `CHECK_INTERVAL` - Optional monitoring settings

3. Run:
```bash
python zxnodes_bot.py
```

## Notes
- The bot expects `lxc` command available on the host.
- The bot uses the logo: https://i.imgur.com/aQH8mZN.jpeg
- I replaced occurrences of `UNIXNODE` → `ZXNODES` across the code and updated container name prefixes where found.

If you want additional changes (different logo size, dockerfile, or a systemd service file), tell me and I will add them.
